Amazing Slider
Version 7.2
Copyright 2019 Magic Hills Pty Ltd
http://amazingslider.com/


Overview
-----------------------------------------------------------------------

Amazing Slider is an easy-to-use Windows & Mac app for creating beautiful, professional, responsive jQuery Slider, Video Gallery and WordPress Slider Plugin.

Links
-----------------------------------------------------------------------

Terms of Use: https://amazingslider.com/terms-of-use/
Download Free Versions for Windows and Mac:  http://amazingslider.com/downloads/
Online Examples:  http://amazingslider.com/examples/
Upgrade to Commercial Versions:  http://amazingslider.com/order/
Quick Start Guide:  http://amazingslider.com/help/
Contact Us: http://amazingslider.com/contact/